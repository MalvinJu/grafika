Kelompok 3

Compile: g++ -o planetest *.h Plane_driver.cpp Color.cpp circle.cpp HalfCircle.cpp LineDrawer.cpp Screen.cpp shape.cpp Point.cpp -pthread -std=c++11


Pembagian Kerja
13514032 - Chalvin				: 2D Transformation
13514034 - Evita Chandra		: Parasut man
13514038 - Nugroho Satriyanto	: cannon
13514040 - Devin Lukianto		: thread, gerakkan parabola
13514042 - Friska				: pecahan pesawat, baling-baling
13514044 - Malvin Juanda		: collision
13514046 - Albert Logianto		: animasi, thread