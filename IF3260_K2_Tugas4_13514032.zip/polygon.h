#ifndef __POLYGON__
#define __POLYGON__
#include "LineDrawer.h"

class Shape{

public:


};

#endif                                                   